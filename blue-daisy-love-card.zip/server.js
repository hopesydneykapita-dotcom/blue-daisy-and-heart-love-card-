const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const CARD_TOKEN = process.env.CARD_TOKEN;
const OWNER_EMAIL = process.env.OWNER_EMAIL;
const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL;

app.use(express.json({ limit: "12kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ ready: Boolean(CARD_TOKEN && OWNER_EMAIL && RESEND_API_KEY && FROM_EMAIL) });
});

app.post("/api/reply", async (req, res) => {
  if (!CARD_TOKEN || !OWNER_EMAIL || !RESEND_API_KEY || !FROM_EMAIL) {
    return res.status(503).json({ error: "The response service is not configured yet." });
  }

  const token = String(req.body.token || "");
  const message = String(req.body.message || "").trim();

  if (token !== CARD_TOKEN) return res.status(403).json({ error: "This card link is not valid." });
  if (message.length < 2) return res.status(400).json({ error: "Write a little about your day first." });
  if (message.length > 3000) return res.status(400).json({ error: "Please keep your reply under 3,000 characters." });

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: [OWNER_EMAIL],
        subject: "A little message from your love card 💙",
        text: `They answered “How was your day?”\\n\\n${message}\\n\\nSent from your Blue Daisy Love Card.`
      })
    });

    if (!response.ok) {
      const details = await response.text();
      console.error("Email provider error:", details);
      return res.status(502).json({ error: "Your message could not be sent just now. Please try again later." });
    }
    return res.json({ ok: true });
  } catch (error) {
    console.error("Reply delivery failed:", error);
    return res.status(500).json({ error: "Something went wrong while sending your message." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Blue Daisy Love Card listening on ${PORT}`));
