const screens = [...document.querySelectorAll(".screen")];
const token = new URLSearchParams(location.search).get("k") || "";
const show = (id) => {
  screens.forEach(s => s.classList.toggle("active", s.id === id));
  if (id === "miss") burstHearts(24);
  window.scrollTo({ top: 0, behavior: "smooth" });
};
function burstHearts(count = 16) {
  const layer = document.getElementById("confetti");
  const symbols = ["♡", "♥", "✧", "💙", "💗"];
  for (let i = 0; i < count; i++) {
    const heart = document.createElement("span");
    heart.className = "floating-heart";
    heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    heart.style.left = `${Math.random() * 100}%`;
    heart.style.animationDelay = `${Math.random() * .9}s`;
    heart.style.fontSize = `${14 + Math.random() * 18}px`;
    layer.appendChild(heart);
    setTimeout(() => heart.remove(), 5000);
  }
}
document.getElementById("openBtn").addEventListener("click", () => show("miss"));
document.getElementById("missBtn").addEventListener("click", () => show("day"));
const reply = document.getElementById("reply");
reply.addEventListener("input", () => {
  document.getElementById("counter").textContent = `${reply.value.length} / 3000`;
});
document.getElementById("replyForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const status = document.getElementById("status");
  const sendBtn = document.getElementById("sendBtn");
  if (!token) {
    status.textContent = "This preview has no private link token yet. Set CARD_TOKEN when deploying.";
    return;
  }
  sendBtn.disabled = true;
  sendBtn.textContent = "Sending…";
  status.textContent = "";
  try {
    const response = await fetch("/api/reply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, message: reply.value })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not send your message.");
    burstHearts(32);
    show("final");
  } catch (error) {
    status.textContent = error.message || "Could not send your message. Please try again.";
  } finally {
    sendBtn.disabled = false;
    sendBtn.innerHTML = 'Send it to me <span>↗</span>';
  }
});
