# Blue Daisy Love Card 💙💗

A mobile-friendly interactive love card with neon pink + electric blue, blue daisies, floating hearts, a “How was your day?” reply box, and a final glowing calligraphy M.

## What works
- Four-screen card flow and responsive styling.
- Reply form validates the text and sends it through the backend to the email you configure.
- The reply is not saved to a database by this app; the server forwards it to your email using Resend.
- A private link token (`?k=...`) protects the reply endpoint from casual use.

## Important: a live link is not created yet
This project must be deployed to a hosting provider and connected to an email sender. You must set the environment variables in the host dashboard. Do not put secrets in the browser code or commit them to Git.

## Deploy on Render
1. Create accounts at GitHub, Render, and Resend if you do not already have them.
2. Upload this project to a new GitHub repository.
3. In Render, create a **New Web Service** and connect the repository. Render should detect `render.yaml`; alternatively use build command `npm install` and start command `npm start`.
4. Add these environment variables in Render:
   - `CARD_TOKEN`: a long random string, ideally 32+ characters.
   - `OWNER_EMAIL`: the inbox that should receive the reply.
   - `RESEND_API_KEY`: your Resend API key.
   - `FROM_EMAIL`: a sender address/domain verified in Resend.
5. Deploy and wait for the service to become live. Test `/api/status`; it should return `{"ready":true}`.
6. Your shareable card URL is your Render service URL plus `?k=` and the exact `CARD_TOKEN`, for example `https://your-service.onrender.com/?k=YOUR_CARD_TOKEN`. Send that complete link to him.

## Test locally
Requires Node.js 18+.
1. Copy `.env.example` values into your terminal environment (or use a local `.env` loader if you install one; do not commit `.env`).
2. Set the four variables listed above.
3. Run `npm install` and `npm start`, then open `http://localhost:3000/?k=YOUR_CARD_TOKEN`.

## Privacy and safety notes
- Anyone who has the full private link can use it; share it only with the intended person.
- Replies are delivered to the inbox you configure. Email delivery providers may process message data.
- This is a romantic card, not a secure messaging platform. Avoid asking for sensitive personal information.
- Resend sender verification and account limits may apply. Do not share your API key or email account password.
